package com.summer.TestSummer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class SummerTest {
	String actual;
	@BeforeTest
	public void initialize() {
		actual = "";
	}

	@Test(priority=1,dataProvider="summerData")
	public void inputTest(String inputVal,String extension) throws IOException, InterruptedException {
		String[] cmd = {
				"cmd",
				"/c",
				"echo \""+inputVal+"\" | sh summer.sh",
				extension
		};
		Runtime run = Runtime.getRuntime();
		Process pr = run.exec(cmd);
		pr.waitFor();
		BufferedReader buf = new BufferedReader(new InputStreamReader(pr.getInputStream()));
		String actualval = null;
		while ((actual=buf.readLine())!=null) {
			System.out.println(actual);
			actualval = actual;
		}
		if (extension == "-x") {
			Assert.assertEquals(actualval, "39", "Hexa value Assertion  Pass");
		} else if (extension == "") {
			if (inputVal == "qq") {
				Assert.assertNotSame(actualval,"6","Fails Assertion as there are no digits in the Input" );
			} else {
				Assert.assertEquals(actualval,"6","Sum of the Digits Assertion Pass" );
			}
		}else{
			System.out.println("Incorrect extension");
		}
	}	
	
/*	
	@Test(priority=2,dataProvider="summerFileData")
	public void fileInputTest(String inputVal,String fileName) throws IOException, InterruptedException {
		String[] cmd = {
				"cmd",
				"/c",
				"echo \""+inputVal+"\" > ",
				fileName
		};
		Runtime run = Runtime.getRuntime();
		Process pr = run.exec(cmd);
		pr.waitFor();
		BufferedReader buf = new BufferedReader(new InputStreamReader(pr.getInputStream()));
		String actualval2 = null;
		while ((actual=buf.readLine())!=null) {
			System.out.println("File Created Succesfully");
		}
		// Second Command to execute the summer.sh using file
		String[] cmd1 = {
				"cmd",
				"/c",
				"sh summer.sh -f ",
				fileName
		};
		Runtime run1 = Runtime.getRuntime();
		Process pr1 = run1.exec(cmd1);
		pr.waitFor();
		BufferedReader buf1 = new BufferedReader(new InputStreamReader(pr1.getInputStream()));
		while ((actual=buf1.readLine())!=null) {
			actualval2 = actual;
		}
		if (fileName == "file.tmp") {
			Assert.assertEquals(actualval2, "6", "File input of digits Assertion Pass");
		} else if (fileName == "file1.tmp") {
			Assert.assertEquals(actualval2, "10", "Assertion Pass");
		}else {
			System.out.println("Incorrect file name");
		}
	}


	@DataProvider(name="summerFileData") 
	public static Object[][] getSummerData(ITestContext context) {
		String testname = context.getName();
		if ("FileInputTest".equals(testname)) {
			return new Object[][]{{"abc123","file.tmp"}, {"abc1234","file1.tmp"}};		
		}else {
			return null;
		}
	}

*/

	@DataProvider(name="summerData") 
	public static Object[][] getFileSummerData(ITestContext context) {
		String testname = context.getName();
		if("STDINTest".equals(testname)){
			return new Object[][]{{"abc123",""}, {"abc123","-x"},{"qq",""}};
		}else {
			return null;
		}
	}

	@AfterTest
	public void cleanup()
	{
		actual = null;
	}

}

