package com.summer.TestSummer;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.AfterTest;

public class SummerFileTest {
	
	String actual;

  @BeforeTest
  public void beforeTest() {
	  actual = "";
  }
  
	@Test(priority=1,dataProvider="summerFileData")
	public void fileInputTest(String inputVal,String fileName) throws IOException, InterruptedException {
		String[] cmd = {
				"cmd",
				"/c",
				"echo \""+inputVal+"\" > ",
				fileName
		};
		Runtime run = Runtime.getRuntime();
		Process pr = run.exec(cmd);
		pr.waitFor();
		BufferedReader buf = new BufferedReader(new InputStreamReader(pr.getInputStream()));
		String actualval2 = null;
		while ((actual=buf.readLine())!=null) {
			System.out.println("File Created Succesfully");
		}
		// Second Command to execute the summer.sh using file
		String[] cmd1 = {
				"cmd",
				"/c",
				"sh summer.sh -f ",
				fileName
		};
		Runtime run1 = Runtime.getRuntime();
		Process pr1 = run1.exec(cmd1);
		pr.waitFor();
		BufferedReader buf1 = new BufferedReader(new InputStreamReader(pr1.getInputStream()));
		while ((actual=buf1.readLine())!=null) {
			actualval2 = actual;
		}
		if (fileName == "file.tmp") {
			Assert.assertEquals(actualval2, "6", "File input of digits Assertion Pass");
		} else if (fileName == "file1.tmp") {
			Assert.assertEquals(actualval2, "10", "Assertion Pass");
		}else {
			System.out.println("Incorrect file name");
		}
	}


	@DataProvider(name="summerFileData") 
	public static Object[][] getSummerData(ITestContext context) {
		String testname = context.getName();
		if ("FileInputTest".equals(testname)) {
			return new Object[][]{{"abc123","file.tmp"}, {"abc1234","file1.tmp"}};		
		}else {
			return null;
		}
	}


  @AfterTest
  public void afterTest() {
	  actual = null;
  }

}
