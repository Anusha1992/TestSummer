#!/bin/bash

IN="/dev/stdin"
HEX=0

while test $# -gt 0; do
    case "$1" in
        -f)
            shift
            if test $# -gt 0; then
                IN=$1
            else
                echo "Missing FILE from -f"
                echo "0"
                exit 1
            fi
            shift
            ;;
        -x)
            shift
            HEX=1
            ;;
        *)
            break
            ;;
    esac
done

function get_val {
    case $1 in
        [1-9]*)
            echo $1
            ;;
        [a-fA-F]*)
            if [[ "1" -eq "${HEX}" ]]
            then
                echo $((0x$1))
            else
                echo 0
            fi
            ;;
        *)
            echo 0
            ;;
    esac
}

sum=0
TOREAD=$(cat ${IN})
while read -r -n 1 element; do
    converted=$(get_val ${element})
    sum=$((${sum}+${converted}))
done <<< "${TOREAD}"
echo ${sum}

